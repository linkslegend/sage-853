<article class="post span4 blog-slider yt-video" id="post-" itemscope="" itemtype="http://schema.org/BlogPosting" style="width: 100%; display: inline-block;">
  <header>
  <h2 class="entry-title yt-video" itemprop="name headline"><a title="SKF Gedrehte Dichtungen" rel="bookmark" href="" tabindex="0">SKF Gedrehte Dichtungen</a></h2>
  </header>
  <div class="entry-summary yt-video" itemprop="articleBody">
  <img class="lozad" src="https://www.achema.de/fileadmin/user_upload/Bilder/Logos/ACHEMA/achema2018/ac18_banner_234_60.jpg">
  <div class="yt-content">
  Messe1</br>
  Wir stellen aus auf der	ACHEMA <br />
  Weltforum und Internationale Leitmesse der Prozessindustrie<br />
  11.-15. Juni 2018 <br />
  Frankfurt am Main<br />
  Halle 9, Stand D 18<br />
  </div>
  </div>
</article>

<article class="post span4 blog-slider yt-video" id="post-" itemscope="" itemtype="http://schema.org/BlogPosting" style="width: 100%; display: inline-block;">
  <header>
  <h2 class="entry-title yt-video" itemprop="name headline"><a title="SKF Gedrehte Dichtungen" rel="bookmark" href="" tabindex="0">SKF Gedrehte Dichtungen</a></h2>
  </header>
  <div class="entry-summary yt-video" itemprop="articleBody">
  <img class="lozad" src="https://www.achema.de/fileadmin/user_upload/Bilder/Logos/ACHEMA/achema2018/ac18_banner_234_60.jpg">
  <div class="yt-content">
  Messe2</br>
  Wir stellen aus auf der	ACHEMA <br />
  Weltforum und Internationale Leitmesse der Prozessindustrie<br />
  11.-15. Juni 2018 <br />
  Frankfurt am Main<br />
  Halle 9, Stand D 18<br />
  </div>
  </div>
</article>

<article class="post span4 blog-slider yt-video" id="post-" itemscope="" itemtype="http://schema.org/BlogPosting" style="width: 100%; display: inline-block;">
  <header>
  <h2 class="entry-title yt-video" itemprop="name headline"><a title="SKF Gedrehte Dichtungen" rel="bookmark" href="" tabindex="0">SKF Gedrehte Dichtungen</a></h2>
  </header>
  <div class="entry-summary yt-video" itemprop="articleBody">
  <img class="lozad" src="https://www.achema.de/fileadmin/user_upload/Bilder/Logos/ACHEMA/achema2018/ac18_banner_234_60.jpg">
  <div class="yt-content">
  Messe3</br>
  Wir stellen aus auf der	ACHEMA <br />
  Weltforum und Internationale Leitmesse der Prozessindustrie<br />
  11.-15. Juni 2018 <br />
  Frankfurt am Main<br />
  Halle 9, Stand D 18<br />
  </div>
  </div>
</article>
